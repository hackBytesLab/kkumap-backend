
# Frontend (GitHub Pages)
ไฟล์สำหรับโฮสต์บน GitHub Pages แสดงแผนที่ + เส้นทาง + ป้าย + รถวิ่งแบบจำลอง

## ขั้นตอน
1) แก้ `script.js` → ตั้งค่า `API_URL` ให้เป็น URL ของ backend (เช่น https://kkumap-backend.onrender.com)
2) แก้ `index.html` → ใส่ Google Maps API Key ที่ตัวแปร `GMAPS_API_KEY`
3) Push ทั้งโฟลเดอร์นี้ขึ้น repo → เปิด GitHub Pages (Settings > Pages)

> ถ้าใช้ Google Maps API ควร Restrict HTTP referrers ให้รวมโดเมน `https://<username>.github.io/*`
