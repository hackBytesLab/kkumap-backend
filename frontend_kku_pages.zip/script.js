
// ===== Config =====
const API_URL = 'https://YOUR-BACKEND.onrender.com'; // แก้เป็น URL ของ backend (Render/Railway) ก่อน deploy
const kkuCenter = { lat: 16.475, lng: 102.824 };
const INITIAL_ZOOM = 15;
const REFRESH_MS = 5000;

// ===== State =====
let map;
let routePolylines = {};
let stopMarkers = {};
let vehicleMarkers = {};
let currentRouteId = null;

// ===== Utils =====
async function fetchJSON(url){ const r = await fetch(url); return r.json(); }

function clearPolylines(){
  Object.values(routePolylines).forEach(p => p.setMap(null));
  routePolylines = {};
}
function clearStops(routeId){
  if (!stopMarkers[routeId]) return;
  for (const m of stopMarkers[routeId]) m.setMap(null);
  delete stopMarkers[routeId];
}
function clearVehicles(routeId){
  if (!vehicleMarkers[routeId]) return;
  Object.values(vehicleMarkers[routeId]).forEach(m => m.setMap(null));
  delete vehicleMarkers[routeId];
}

// ===== Map Drawing =====
async function drawRoute(route){
  const path = route.shape.map(([lat,lng]) => ({lat, lng}));
  const poly = new google.maps.Polyline({
    path, strokeColor: route.color || '#0066cc', strokeOpacity: 0.9, strokeWeight: 4, map
  });
  routePolylines[route.id] = poly;
}

async function drawStops(routeId){
  const res = await fetchJSON(`${API_URL}/stops?route_id=${routeId}`);
  stopMarkers[routeId] = res.data.map(s => new google.maps.Marker({
    position: {lat:s.lat, lng:s.lng}, map, title: s.name,
    icon: { path: google.maps.SymbolPath.CIRCLE, scale: 5 }
  }));
}

async function updateVehicles(routeId){
  const res = await fetchJSON(`${API_URL}/vehicles?route_id=${routeId}`);
  if (!vehicleMarkers[routeId]) vehicleMarkers[routeId] = {};
  const cur = vehicleMarkers[routeId];

  // place/move markers
  for (const v of res.data){
    if (!cur[v.id]){
      cur[v.id] = new google.maps.Marker({
        position:{lat:v.lat, lng:v.lng}, map,
        icon:{ url: 'https://maps.google.com/mapfiles/ms/icons/bus.png' },
        title: `${v.id} • ${routeId}`
      });
    }else{
      cur[v.id].setPosition({lat:v.lat, lng:v.lng});
    }
  }
  // remove stale
  const liveIds = new Set(res.data.map(v=>v.id));
  for (const id of Object.keys(cur)){
    if (!liveIds.has(id)){ cur[id].setMap(null); delete cur[id]; }
  }
}

function startVehicleLoop(routeId){
  async function tick(){
    if (currentRouteId) await updateVehicles(currentRouteId);
    setTimeout(tick, REFRESH_MS);
  }
  tick();
}

// ===== Init =====
async function populateRoutes(){
  const sel = document.getElementById('route-select');
  const routes = (await fetchJSON(`${API_URL}/routes`)).data;
  sel.innerHTML = routes.map(r=>`<option value="${r.id}">${r.name}</option>`).join('');
  if (routes.length){
    currentRouteId = routes[0].id;
    await drawRoute(routes[0]);
    await drawStops(routes[0].id);
  }
  sel.addEventListener('change', async (e) => {
    const rid = e.target.value;
    // clear old
    clearPolylines();
    if (currentRouteId) { clearStops(currentRouteId); clearVehicles(currentRouteId); }
    currentRouteId = rid;
    const route = routes.find(r=>r.id===rid);
    await drawRoute(route);
    await drawStops(rid);
  });
}

window.initMap = async function initMap(){
  map = new google.maps.Map(document.getElementById('map'), {
    center: kkuCenter, zoom: INITIAL_ZOOM, mapTypeControl: false
  });
  document.getElementById('back-center').addEventListener('click', ()=>{
    map.setCenter(kkuCenter); map.setZoom(INITIAL_ZOOM);
  });
  await populateRoutes();
  startVehicleLoop(currentRouteId);
};

// simple client-side stop search (filter titles)
document.addEventListener('DOMContentLoaded', () => {
  const search = document.getElementById('search');
  search.addEventListener('input', () => {
    const q = search.value.trim().toLowerCase();
    if (!currentRouteId || !stopMarkers[currentRouteId]) return;
    for (const m of stopMarkers[currentRouteId]){
      const match = (m.getTitle() || '').toLowerCase().includes(q);
      m.setVisible(match || q === '');
    }
  });
});
